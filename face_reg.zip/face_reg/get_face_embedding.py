import os
import numpy as np
import cv2
from keras_facenet import FaceNet

# Load the FaceNet model
embedder = FaceNet()

# Define dataset path
dataset_path = "organized_dataset_train"
embeddings = []
labels = []

def get_face_embedding(image_path):
    image = cv2.imread(image_path)
    image = cv2.resize(image, (160, 160))
    image = np.expand_dims(image, axis=0)
    embedding = embedder.embeddings(image)
    return embedding[0]

# Process each person's folder
for person in os.listdir(dataset_path):
    person_path = os.path.join(dataset_path, person)
    if not os.path.isdir(person_path):
        continue

    print(f"Processing {person}...")

    for img_name in os.listdir(person_path):
        img_path = os.path.join(person_path, img_name)
        embedding = get_face_embedding(img_path)
        embeddings.append(embedding)
        labels.append(person)

# Convert to NumPy arrays
embeddings = np.array(embeddings)
labels = np.array(labels)

# Save extracted features
np.save("face_embeddings.npy", embeddings)
np.save("face_labels.npy", labels)

print("✅ Feature extraction completed! Face embeddings saved as 'face_embeddings.npy' and 'face_labels.npy'.")