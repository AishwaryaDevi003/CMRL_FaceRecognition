import os
import shutil

# Define the input and output folders
input_folder = "preprocessed_images"  # Folder containing preprocessed images
output_folder = "organized_dataset_train"  # Folder to save organized dataset

# Create output folder if it doesn't exist
os.makedirs(output_folder, exist_ok=True)

# Organize images into the output folder
for person_name in os.listdir(input_folder):
    person_folder = os.path.join(input_folder, person_name)
    if os.path.isdir(person_folder):
        # Create a corresponding folder in the output directory
        output_person_folder = os.path.join(output_folder, person_name)
        os.makedirs(output_person_folder, exist_ok=True)

        # Copy images to the new organized folder
        for img_name in os.listdir(person_folder):
            img_path = os.path.join(person_folder, img_name)
            if os.path.isfile(img_path):  # Ensure it's a file
                shutil.copy(img_path, output_person_folder)
                print(f"Copied {img_name} to {output_person_folder}")

print("✅ Images organized successfully into 'organized_dataset_train'.")
