import os
import cv2
import numpy as np
import random

# Input and output folders
input_folder = "preprocessed_images"
output_folder = "augmented_images"

# Create output folder if it doesn't exist
os.makedirs(output_folder, exist_ok=True)

def augment_image(image):
    # Random horizontal flip (50% chance)
    if random.random() > 0.5:
        image = cv2.flip(image, 1)

    # Random rotation (-15 to +15 degrees)
    angle = random.randint(-15, 15)
    h, w = image.shape[:2]
    M = cv2.getRotationMatrix2D((w//2, h//2), angle, 1)
    image = cv2.warpAffine(image, M, (w, h))

    # Random brightness adjustment (-30 to +30)
    brightness = random.randint(-30, 30)
    image = np.clip(image.astype(np.int16) + brightness, 0, 255).astype(np.uint8)

    # Random Gaussian noise (30% chance)
    if random.random() > 0.7:
        noise = np.random.normal(0, 10, image.shape).astype(np.int16)
        image = np.clip(image.astype(np.int16) + noise, 0, 255).astype(np.uint8)

    return image

def augment_dataset():
    if not os.path.exists(input_folder):
        print(f"Error: The directory '{input_folder}' does not exist.")
        return

    for person in os.listdir(input_folder):
        person_path = os.path.join(input_folder, person)
        if not os.path.isdir(person_path):
            print(f"Skipping non-folder file: {person}")
            continue

        output_person_path = os.path.join(output_folder, person)
        os.makedirs(output_person_path, exist_ok=True)

        for img_name in os.listdir(person_path):
            img_path = os.path.join(person_path, img_name)
            image = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)

            if image is None:
                print(f"Skipping {img_name}: Unable to read.")
                continue

            # Save original grayscale image
            original_path = os.path.join(output_person_path, f"orig_{img_name}")
            cv2.imwrite(original_path, image)

            # Apply and save multiple augmentations
            for i in range(3):  # Generate 3 augmented versions per image
                augmented_image = augment_image(image)
                aug_save_path = os.path.join(output_person_path, f"aug_{i}_{img_name}")
                cv2.imwrite(aug_save_path, augmented_image)
                print(f"✅ Saved: {aug_save_path}")

augment_dataset()