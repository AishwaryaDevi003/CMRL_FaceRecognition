import cv2
import numpy as np
from keras_facenet import FaceNet
from mtcnn import MTCNN
from tensorflow.keras.models import load_model
from sklearn.preprocessing import LabelEncoder

def load_model_and_encoder(model_path, label_encoder_path):
    model = load_model(model_path)
    label_encoder = LabelEncoder()
    label_encoder.classes_ = np.load(label_encoder_path)
    return model, label_encoder

def recognize_faces(frame, detector, embedder, model, label_encoder):
    faces = detector.detect_faces(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    for face in faces:
        x, y, w, h = face['box']
        face_image = frame[y:y+h, x:x+w]
        face_image = cv2.resize(face_image, (160, 160))
        face_image = np.expand_dims(face_image, axis=0)
        
        # Get face embedding
        face_embedding = embedder.embeddings(face_image)
        
        # Predict the label
        prediction = model.predict(face_embedding)
        predicted_label_index = np.argmax(prediction)
        label = label_encoder.inverse_transform([predicted_label_index])[0]

        # Draw box and label on the frame
        cv2.putText(frame, label, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

def main():
    model, label_encoder = load_model_and_encoder("face_recognition_model.h5", "face_labels.npy")
    embedder = FaceNet()
    detector = MTCNN()

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error: Could not open webcam.")
        return

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Error: Could not read frame.")
            break

        recognize_faces(frame, detector, embedder, model, label_encoder)

        cv2.imshow("Face Recognition", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()