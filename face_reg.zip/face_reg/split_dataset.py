import os
import shutil
from sklearn.model_selection import train_test_split

# Define the input and output folders
input_folder = "preprocessed_images"  # Ensure this is a directory
train_folder = "train"                 # Folder to save training images
test_folder = "test"                   # Folder to save testing images

# Check if the input folder exists
if not os.path.exists(input_folder):
    print(f"Error: The directory '{input_folder}' does not exist.")
    exit(1)

# Create output folders if they don't exist
os.makedirs(train_folder, exist_ok=True)
os.makedirs(test_folder, exist_ok=True)

# Prepare lists to hold image paths and labels
image_paths = []
labels = []

# Load images and labels
for person_name in os.listdir(input_folder):
    person_folder = os.path.join(input_folder, person_name)
    if os.path.isdir(person_folder):
        for img_name in os.listdir(person_folder):
            img_path = os.path.join(person_folder, img_name)
            image_paths.append(img_path)
            labels.append(person_name)  # Use the folder name as the label

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(image_paths, labels, test_size=0.2, random_state=42)

# Function to copy images to the respective folders
def copy_images(image_list, target_folder, labels):
    for img_path, label in zip(image_list, labels):
        # Create label directory if it doesn't exist
        label_folder = os.path.join(target_folder, label)
        os.makedirs(label_folder, exist_ok=True)
        
        # Copy the image to the target folder
        shutil.copy(img_path, label_folder)

# Copy training and testing images to their respective folders
copy_images(X_train, train_folder, y_train)
copy_images(X_test, test_folder, y_test)

print(f"Training images: {len(X_train)}")
print(f"Testing images: {len(X_test)}")
