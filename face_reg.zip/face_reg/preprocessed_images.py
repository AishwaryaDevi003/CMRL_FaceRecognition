import cv2
import os
import numpy as np
from mtcnn import MTCNN

# Input and output folders
input_folder = "captured_images"
output_folder = "preprocessed_images"

# Create output folder if it doesn't exist
os.makedirs(output_folder, exist_ok=True)

# Initialize face detector (MTCNN)
detector = MTCNN()

def preprocess_image(image):
    # Convert to RGB (MTCNN requires RGB images)
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

    # Detect faces
    faces = detector.detect_faces(image_rgb)

    if faces:
        x, y, w, h = faces[0]['box']  # Extract first detected face
        face = image_rgb[y:y+h, x:x+w]  # Crop face

        # Resize face to required size (160x160 for FaceNet)
        face_resized = cv2.resize(face, (160, 160))

        # Normalize pixel values (convert to 0-1)
        face_normalized = face_resized / 255.0

        return face_normalized
    else:
        return None

def preprocess_images():
    for person_name in os.listdir(input_folder):
        person_folder = os.path.join(input_folder, person_name)
        if os.path.isdir(person_folder):
            for img_name in os.listdir(person_folder):
                img_path = os.path.join(person_folder, img_name)
                image = cv2.imread(img_path)

                if image is None:
                    print(f"Skipping {img_name}: Unable to read.")
                    continue

                face_normalized = preprocess_image(image)
                if face_normalized is not None:
                    save_path = os.path.join(output_folder, person_name, img_name)
                    os.makedirs(os.path.dirname(save_path), exist_ok=True)
                    cv2.imwrite(save_path, (face_normalized * 255).astype(np.uint8))
                    print(f"Processed and saved: {save_path}")
                else:
                    print(f"No face detected in {img_name}, skipping.")

# Run preprocessing
preprocess_images()